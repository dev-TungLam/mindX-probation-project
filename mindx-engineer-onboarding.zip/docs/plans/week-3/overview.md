# Week 3: AI Application

## Objectives
- Build an AI applicaiton with specific knowledge and MCPs

## Acceptance criterias
- [ ] AI application is live and accessible.
- [ ] AI demonstrates domain-specific knowledge and provides accurate, relevant responses.
- [ ] MCPs are functional - AI can successfully call external tools and services.
- [ ] Performance metrics and product metrics setup
